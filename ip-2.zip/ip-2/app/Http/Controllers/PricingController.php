<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PricingController
{
    public function index()
    {
        return view('pricing.index');
    }
}
