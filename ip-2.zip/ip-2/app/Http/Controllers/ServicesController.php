<?php

namespace App\Http\Controllers;

use App\Models\DomainExtension;
use App\Models\HostingServer;

class ServicesController
{
    public function index()
    {
        // Alan adı ve hosting hizmetlerini al
        $domainServices = DomainExtension::all();
        $hostingServices = HostingServer::all();

        // Verileri blade dosyasına gönder
        return view('services.index', compact('domainServices', 'hostingServices'));
    }
}
