<?php

namespace App\Http\Controllers;

use App\Models\HostingPackage;
use Illuminate\Http\Request;

class HostingController
{
    public function order($id)
    {
        $package = HostingPackage::find($id);

        if (!$package) {
            return redirect()->route('home')->with('error', 'Seçilen hosting paketi bulunamadı.');
        }

        // Sipariş sayfasına yönlendirme veya işlem yapma
        return view('hosting.order', compact('package'));
    }
    public function processOrder(Request $request)
    {
        $packageId = $request->input('package_id');

        $package = HostingPackage::find($packageId);

        if (!$package) {
            return redirect()->route('home')->with('error', 'Seçilen hosting paketi bulunamadı.');
        }


        return redirect()->route('home')->with('success', 'Siparişiniz başarıyla tamamlandı.');
    }
    public function index()
    {
        $hostingPackages = HostingPackage::all();
        return view('hosting.index', compact('hostingPackages'));
    }
}
