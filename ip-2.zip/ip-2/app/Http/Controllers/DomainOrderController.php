<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DomainOrderController
{
    public function create($id)
    {
        // Alan adı detaylarını getir
        $domainService = DomainService::findOrFail($id);

        // Sipariş sayfasına yönlendir
        return view('domain.order', compact('domainService'));
    }
    public function submit(Request $request, $id)
    {
        // Alan adı siparişi kaydetme işlemleri
        $domainService = DomainService::findOrFail($id);

        // Sipariş işlemleri burada yapılabilir
        // Örneğin, siparişleri bir tabloya kaydedebilirsiniz.

        return redirect()->route('services')->with('success', 'Siparişiniz başarıyla tamamlandı!');
    }

}
