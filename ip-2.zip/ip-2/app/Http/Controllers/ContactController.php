<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController
{
    public function index()
    {
        return view('contact');
    }
    public function submit(Request $request)
    {
        // Form verilerini almak
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'message' => 'required|string',
        ]);

        return response()->json($data);
    }
}
