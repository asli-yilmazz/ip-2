<?php

namespace App\Http\Controllers;

use App\Models\DomainPricing;
use App\Models\HostingPricing;
use App\Models\DomainExtension;
use App\Models\HostingPackage;
use App\Models\Testimonial;
use Illuminate\Routing\Controller;


class HomeController extends Controller
{
    public function index()
    {
        $domainExtensions = DomainExtension::all();
        $domainPricings = DomainPricing::all();
        $hostingPackages = HostingPackage::all();
        $testimonials = Testimonial::all();

        return view('home', compact('domainExtensions', 'domainPricings', 'hostingPackages', 'testimonials'));
    }
}
