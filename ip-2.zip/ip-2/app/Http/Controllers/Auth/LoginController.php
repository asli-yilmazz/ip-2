<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController
{
    public function logout()
    {
        Auth::logout();
        return redirect('/');
    }
    public function showLoginForm()
    {
        return view('auth.login');
    }

    // Giriş işlemini yap
    public function login(Request $request)
    {
        // Form verilerini doğrulama
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        // Kullanıcıyı giriş yapma
        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            // Başarılı giriş sonrası ana sayfaya yönlendirme
            return redirect()->intended('/');
        }

        // Giriş başarısız olursa
        return back()->withErrors(['email' => 'Email veya şifre yanlış.']);
    }
}
