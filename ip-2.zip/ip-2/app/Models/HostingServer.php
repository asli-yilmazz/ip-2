<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HostingServer extends Model
{
    use HasFactory;

    protected $fillable = [
        'server_name',
        'ip_address',
        'location',
        'max_storage',
        'available_storage',
        'status',
    ];

    public function hostingOrders()
    {
        return $this->hasMany(HostingOrder::class);
    }
}
