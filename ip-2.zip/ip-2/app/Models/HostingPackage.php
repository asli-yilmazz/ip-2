<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HostingPackage extends Model
{
    use HasFactory;

    protected $fillable = [
        'package_name',
        'disk_space',
        'bandwidth',
        'email_accounts',
        'databases',
        'description',
        'price',
    ];

    public function hostingPricings()
    {
        return $this->hasMany(HostingPricing::class);
    }

    public function hostingOrders()
    {
        return $this->hasMany(HostingOrder::class);
    }
    public function carts()
    {
        return $this->morphMany(Cart::class, 'cartable');
    }
}
