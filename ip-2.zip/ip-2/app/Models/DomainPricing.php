<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DomainPricing extends Model
{
    use HasFactory;

    protected $fillable = [
        'extension_id',
        'created_price',
        'updated_price',
    ];

    public function domains()
    {
        return $this->hasMany(Domain::class, 'pricing_id');
    }

    // DomainPricing ile DomainExtension ilişkisi
    public function extension()
    {
        return $this->belongsTo(DomainExtension::class, 'extension_id');
    }
    public function domainExtension()
    {
        return $this->belongsTo(DomainExtension::class, 'domain_extension_id');
    }
}
