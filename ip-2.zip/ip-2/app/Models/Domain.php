<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Domain extends Model
{
    use HasFactory;

    protected $fillable = [
        'domain_name',
        'user_id',
        'extension_id', // Eklendi
        'pricing_id',   // Eklendi
    ];

    // Domain ile domain_extensions ilişkisi
    public function extension()
    {
        return $this->belongsTo(DomainExtension::class, 'extension_id');
    }

    // Domain ile domain_pricings ilişkisi
    public function pricing()
    {
        return $this->belongsTo(DomainPricing::class, 'pricing_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
