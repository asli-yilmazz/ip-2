<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HostingPricing extends Model
{
    use HasFactory;

    protected $fillable = [
        'package_id',
        'billing_cycle',
        'price',
    ];

    public function hostingPackage()
    {
        return $this->belongsTo(HostingPackage::class);
    }
}
