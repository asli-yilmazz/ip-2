<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DomainExtension extends Model
{
    use HasFactory;

    protected $fillable = [
        'extension',
        'annual_price',
        'monthly_price',
        'description',
    ];
    public function domainPricing(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(DomainPricing::class, 'domain_extension_id');
    }

    public function domains()
    {
        return $this->hasMany(Domain::class, 'extension_id');
    }
}
