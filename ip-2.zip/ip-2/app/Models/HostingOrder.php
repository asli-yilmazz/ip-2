<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HostingOrder extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'package_id',
        'domain_id',
        'server_id',
        'order_date',
        'expiry_date',
        'status',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function hostingPackage()
    {
        return $this->belongsTo(HostingPackage::class, 'package_id');
    }

    public function domain()
    {
        return $this->belongsTo(Domain::class);
    }

    public function hostingServer()
    {
        return $this->belongsTo(HostingServer::class, 'server_id');
    }
}
