<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Web Hosting ve Alan Adı Yönetimi'); ?></title>

    <!-- CSS Dosyaları -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">

    <style>
        /* Genel Footer Stilleri */
        footer {
            background-color: #2c3e50; /* Koyu gri arka plan */
            color: #ecf0f1; /* Açık gri metin */
            padding: 20px 0;
            text-align: center;
            font-size: 14px;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Metin Stili */
        footer p {
            margin: 0 0 15px;
        }

        /* Sosyal Bağlantılar */
        .social-links {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .social-links li {
            display: inline-block;
        }

        .social-links a {
            display: inline-block;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            overflow: hidden;
            background-color: #34495e; /* İkonların arka plan rengi */
            transition: background-color 0.3s ease;
        }

        .social-links a:hover {
            background-color: #1abc9c; /* Hover rengini değiştir */
        }

        .social-links img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>
<body>
<header>
    <div class="container">
        <div class="logo">
            <a href="/">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Web Hosting ve Alan Adı Yönetimi">
            </a>
        </div>
    </div>
        <nav class="navbar">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Ana Sayfa</a></li>
                <li><a href="<?php echo e(route('services')); ?>">Hizmetler</a></li>
                <li><a href="<?php echo e(route('pricing')); ?>">Fiyatlandırma</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">İletişim</a></li>
            </ul>
        </nav>
    </div>
</header>

<!-- Ana İçerik Alanı -->
<main>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</main>

<!-- Footer -->
<footer>
    <div class="footer-container">
        <p>&copy; <?php echo e(date('Y')); ?> Web Hosting ve Alan Adı Yönetimi. Tüm Hakları Saklıdır.</p>
        <ul class="social-links">
            <li><a href="#"><img src="<?php echo e(asset('images/facebook-icon.png')); ?>" alt="Facebook"></a></li>
            <li><a href="#"><img src="<?php echo e(asset('images/twitter-icon.png')); ?>" alt="Twitter"></a></li>
            <li><a href="#"><img src="<?php echo e(asset('images/instagram-icon.png')); ?>" alt="Instagram"></a></li>
        </ul>
    </div>
</footer>

<!-- JS Dosyaları -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/layouts/app.blade.php ENDPATH**/ ?>