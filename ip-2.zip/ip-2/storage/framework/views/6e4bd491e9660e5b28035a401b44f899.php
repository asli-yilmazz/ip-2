<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Hosting Orders</h1>
        <table class="table">
            <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Package</th>
                <th>Domain</th>
                <th>Server</th>
                <th>Status</th>
                <th>Order Date</th>
                <th>Expiry Date</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $hostingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->user->name); ?></td>
                    <td><?php echo e($order->hostingPackage->package_name); ?></td>
                    <td><?php echo e($order->domain->domain_name ?? 'N/A'); ?></td>
                    <td><?php echo e($order->hostingServer->server_name ?? 'N/A'); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td><?php echo e($order->order_date); ?></td>
                    <td><?php echo e($order->expiry_date); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/hosting_orders.blade.php ENDPATH**/ ?>