<?php $__env->startSection('title', 'Hosting Siparişi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Hosting Siparişi</h1>
        <p>Seçtiğiniz Paket: <strong><?php echo e($package->name); ?></strong></p>
        <p>Aylık Fiyat: <strong><?php echo e(number_format($package->price, 2)); ?> TL</strong></p>

        <form action="<?php echo e(route('hosting.processOrder')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="package_id" value="<?php echo e($package->id); ?>">
            <button type="submit" class="btn-primary">Siparişi Tamamla</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/hosting/order.blade.php ENDPATH**/ ?>