<?php $__env->startSection('title', 'Hizmetler'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Hizmetlerimiz</h1>
        <p>Hosting ve alan adı hizmetlerimiz hakkında detaylı bilgi alın. İhtiyacınıza uygun hizmet paketlerini keşfedin.</p>

        <!-- Alan Adı Hizmetleri -->
        <section class="domain-services">
            <h2>Alan Adı Hizmetleri</h2>
            <div class="service-list">
                <?php $__currentLoopData = $domainServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="service-item">
                        <h3><?php echo e($domain->name); ?></h3>
                        <p><?php echo e($domain->description); ?></p>
                        <p><strong>Fiyat:</strong> <?php echo e(number_format($domain->price, 2)); ?> TL</p>
                        <a href="<?php echo e(route('domain.order', $domain->id)); ?>" class="btn btn-primary">Satın Al</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <!-- Hosting Hizmetleri -->
        <section class="hosting-services">
            <h2>Hosting Paketleri</h2>
            <div class="service-list">
                <?php $__currentLoopData = $hostingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hosting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="service-item">
                        <h3><?php echo e($hosting->name); ?></h3>
                        <p><?php echo e($hosting->description); ?></p>
                        <p><strong>Fiyat:</strong> <?php echo e(number_format($hosting->price, 2)); ?> TL/ay</p>
                        <a href="<?php echo e(route('hosting.order', $hosting->id)); ?>" class="btn btn-primary">Satın Al</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>

    <style>
        /* Genel Ayarlar */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Başlık */
        h1, h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }

        h2 {
            font-size: 28px;
            margin-top: 40px;
        }

        /* Hizmet Listesi */
        .service-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .service-item {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .service-item h3 {
            font-size: 24px;
            color: #333;
            margin-bottom: 10px;
        }

        .service-item p {
            font-size: 16px;
            margin-bottom: 15px;
            color: #555;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        /* Responsive Tasarım */
        @media (max-width: 768px) {
            .service-list {
                grid-template-columns: 1fr;
            }

            h1 {
                font-size: 28px;
            }

            h2 {
                font-size: 24px;
            }

            .service-item {
                padding: 15px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ArtıTech\Desktop\proje\resources\views/services/index.blade.php ENDPATH**/ ?>