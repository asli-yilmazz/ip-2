<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İletişim</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 16px;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="email"],
        textarea {
            padding: 10px;
            font-size: 14px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        textarea {
            resize: vertical;
            height: 150px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>İletişim Formu</h1>
    <?php if(session('success')): ?>
        <div class="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('contact.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name">Adınız</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div>
            <label for="email">E-posta</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="message">Mesajınız</label>
            <textarea id="message" name="message" required></textarea>
        </div>
        <button type="submit">Gönder</button>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/contact.blade.php ENDPATH**/ ?>