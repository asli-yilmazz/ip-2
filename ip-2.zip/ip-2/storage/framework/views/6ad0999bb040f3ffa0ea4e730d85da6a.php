<?php $__env->startSection('title', 'Ana Sayfa'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <header class="navbar">
        <div class="container">
            <div class="navbar-left">
                <a href="<?php echo e(route('home')); ?>" class="navbar-logo">Web Hosting</a>
            </div>
            <div class="navbar-right">
                <a href="<?php echo e(route('signup')); ?>" class="btn-primary">Kayıt Ol</a>
                <a href="<?php echo e(route('login')); ?>" class="btn-secondary">Giriş Yap</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Web Hosting ve Alan Adı Yönetimi</h1>
            <p>Web siteniz için en güvenilir hosting ve alan adı hizmetleri.</p>
            <a href="<?php echo e(route('services')); ?>" class="btn-primary">Hizmetleri Keşfet</a>
        </div>
    </section>


    <section class="domain-extensions">
        <div class="container">
            <h2>Alan Adı Uzantıları</h2>
            <div class="extension-list">
                <?php $__currentLoopData = $domainExtensions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extension): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="extension-item">
                        <h3><?php echo e($extension->name); ?></h3>
                        <p>Yıllık Fiyat: <?php echo e(number_format($domainPricings->where('domain_extension_id', $extension->id)->first()->price ?? 0, 2)); ?> TL</p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- Hosting Packages Section -->
    <section class="hosting-packages">
        <div class="container">
            <h2>Hosting Paketleri</h2>
            <div class="package-list">
                <?php $__currentLoopData = $hostingPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="package-item">
                        <h3><?php echo e($package->name); ?></h3>
                        <p><?php echo e($package->description); ?></p>
                        <p>Fiyat: <?php echo e($package->price ? number_format($package->price, 2) : 'Fiyat Bilgisi Yok'); ?> TL/ay</p>
                        <a href="<?php echo e(route('hosting.order', $package->id)); ?>" class="btn-secondary">Satın Al</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials">
        <div class="container">
            <h2>Müşteri Yorumları</h2>
            <div class="testimonial-list">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testimonial-item">
                        <blockquote>
                            <p><?php echo e($testimonial->comment); ?></p>
                            <footer>- <?php echo e($testimonial->customer_name); ?></footer>
                        </blockquote>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- Call to Action Section -->
    <section class="cta">
        <div class="container">
            <h2>Web Sitenizi Hemen Kurun!</h2>
            <p>Hosting ve alan adı paketlerimizi keşfedin ve dakikalar içinde yayınlanmaya başlayın.</p>
            <a href="<?php echo e(route('signup')); ?>" class="btn-primary">Hemen Başla</a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ArtıTech\Desktop\proje\resources\views/home.blade.php ENDPATH**/ ?>