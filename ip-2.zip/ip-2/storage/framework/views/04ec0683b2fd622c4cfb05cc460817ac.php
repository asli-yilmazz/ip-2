<!-- resources/views/home.blade.php -->


<?php $__env->startSection('content'); ?>

    <!-- Header (Başlık) -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">My Web Hosting</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Slider (Slayt Gösterisi) -->
    <section id="slider" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php $__currentLoopData = $hostingPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>">
                    <img src="https://via.placeholder.com/1500x500?text=<?php echo e($package->package_name); ?>" class="d-block w-100" alt="<?php echo e($package->package_name); ?>">
                    <div class="carousel-caption d-none d-md-block">
                        <h5><?php echo e($package->package_name); ?></h5>
                        <p><?php echo e($package->disk_space); ?> of storage, <?php echo e($package->bandwidth); ?> bandwidth</p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#slider" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#slider" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </section>

    <!-- Aktif Hosting Siparişleri (Footer'dan önce) -->
    <section class="active-orders">
        <h2>Active Orders</h2>
        <div class="row">
            <?php $__currentLoopData = $hostingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Order #<?php echo e($order->id); ?></h5>
                            <p class="card-text">Package: <?php echo e($order->hostingPackage->package_name); ?></p>
                            <p class="card-text">Expires: <?php echo e($order->expiry_date); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <!-- Footer (Altbilgi) -->
    <footer class="bg-light text-center py-4">
        <p>&copy; 2024 My Web Hosting. All rights reserved.</p>
        <p>Contact us: info@mywebhosting.com</p>
    </footer>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/index.blade.php ENDPATH**/ ?>