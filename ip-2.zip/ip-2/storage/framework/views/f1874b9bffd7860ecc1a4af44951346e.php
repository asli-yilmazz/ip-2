<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap</title>
</head>
<body>
<h1>Giriş Yap</h1>

<form action="<?php echo e(route('login')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="email">E-posta:</label>
    <input type="email" id="email" name="email" required><br>

    <label for="password">Şifre:</label>
    <input type="password" id="password" name="password" required><br>

    <button type="submit">Giriş Yap</button>
</form>
</body>
</html>
<?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/login.blade.php ENDPATH**/ ?>