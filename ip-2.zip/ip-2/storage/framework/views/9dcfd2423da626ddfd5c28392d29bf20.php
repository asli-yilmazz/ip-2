<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fiyatlandırma</title>
    <style>
        /* Genel Ayarlar */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Başlık */
        h1 {
            text-align: center;
            font-size: 36px;
            margin-bottom: 50px;
            color: #007bff;
        }

        /* Pricing Tiers */
        .pricing-tiers {
            display: flex;
            justify-content: space-between;
            gap: 30px;
            flex-wrap: wrap;
        }

        .tier {
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 30%;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .tier:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        /* Plan Başlıkları */
        .tier h2 {
            font-size: 28px;
            color: #333;
            margin-bottom: 15px;
        }

        /* Plan Açıklamaları */
        .tier p {
            font-size: 16px;
            color: #777;
            margin-bottom: 20px;
        }

        /* Fiyatlandırma */
        .tier p strong {
            font-size: 24px;
            color: #007bff;
            font-weight: bold;
        }

        /* Responsive Tasarım */
        @media (max-width: 768px) {
            .pricing-tiers {
                flex-direction: column;
                align-items: center;
            }

            .tier {
                width: 80%;
                margin-bottom: 30px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Fiyatlandırma Planlarımız</h1>
    <div class="pricing-tiers">
        <div class="tier">
            <h2>Temel Plan</h2>
            <p>Bu plan, temel özellikleri içerir.</p>
            <p><strong>Fiyat: 99 TL</strong></p>
        </div>
        <div class="tier">
            <h2>Pro Plan</h2>
            <p>Bu plan, ek özellikler ve destek içerir.</p>
            <p><strong>Fiyat: 199 TL</strong></p>
        </div>
        <div class="tier">
            <h2>Premium Plan</h2>
            <p>Premium özellikler ve öncelikli destek içerir.</p>
            <p><strong>Fiyat: 299 TL</strong></p>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/pricing/index.blade.php ENDPATH**/ ?>