<?php $__env->startSection('title', 'Hizmetler'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Hizmetlerimiz</h1>
        <p>Hosting ve alan adı hizmetlerimiz hakkında bilgi edinin.</p>
    </div>
    <style>
        /* Genel Ayarlar */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Başlık */
        h1 {
            text-align: center;
            font-size: 36px;
            margin-bottom: 20px;
            color: #007bff;
        }

        /* Paragraf */
        p {
            text-align: center;
            font-size: 18px;
            line-height: 1.6;
            margin-top: 10px;
            color: #555;
        }

        /* Responsive Tasarım */
        @media (max-width: 768px) {
            h1 {
                font-size: 28px;
            }

            p {
                font-size: 16px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/services/index.blade.php ENDPATH**/ ?>