<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kayıt Ol</title>
</head>
<body>
<h1>Kayıt Ol</h1>

<?php if(session('success')): ?>
    <p style="color: green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<form action="<?php echo e(route('register')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="name">Ad:</label>
    <input type="text" id="name" name="name" required><br>

    <label for="lastname">Soyad:</label>
    <input type="text" id="lastname" name="lastname" required><br>

    <label for="email">E-posta:</label>
    <input type="email" id="email" name="email" required><br>

    <label for="password">Şifre:</label>
    <input type="password" id="password" name="password" required><br>

    <label for="password_confirmation">Şifre (Tekrar):</label>
    <input type="password" id="password_confirmation" name="password_confirmation" required><br>

    <button type="submit">Kayıt Ol</button>
</form>
</body>
</html>
<?php /**PATH C:\Users\ArtıTech\Desktop\myproject\proje\resources\views/auth/register.blade.php ENDPATH**/ ?>