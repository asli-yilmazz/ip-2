<?php

use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PricingController;
use App\Http\Controllers\ServicesController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HostingController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DomainOrderController;

Route::get('/domain/order/{id}', [DomainOrderController::class, 'create'])->name('domain.order');
Route::post('/domain/order/submit/{id}', [DomainOrderController::class, 'submit'])->name('domain.order.submit');


Route::get('login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('login', [LoginController::class, 'login']);
Route::post('logout', [LoginController::class, 'logout'])->name('logout');


Route::get('/signup', [RegisterController::class, 'showRegistrationForm'])->name('signup');
Route::post('/signup', [RegisterController::class, 'register']);

Route::get('/', [HomeController::class, 'index']);

Route::get('/services', [ServicesController::class, 'index'])->name('services');

Route::get('/hosting/order/{id}', [HostingController::class, 'order'])->name('hosting.order');
Route::post('/hosting/order/process', [HostingController::class, 'processOrder'])->name('hosting.processOrder');
Route::get('/hosting', [HostingController::class, 'index'])->name('hosting.index');

Route::get('/home', [HomeController::class, 'index'])->name('home');

Route::get('/pricing', [PricingController::class, 'index'])->name('pricing');

Route::get('/contact', [ContactController::class, 'index'])->name('contact');

Route::post('/contact/submit', [ContactController::class, 'submit'])->name('contact.submit');

Route::post('/contact/submit', [ContactController::class, 'submit'])->name('contact.submit');
