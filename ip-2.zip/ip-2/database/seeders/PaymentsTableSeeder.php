<?php

namespace Database\Seeders;

use App\Models\Invoice;
use App\Models\Payment;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PaymentsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::all();
        $invoices = Invoice::all();

        // Ödeme yöntemleri
        $paymentMethods = ['credit_card', 'paypal', 'bank_transfer', 'cash'];

        // 10 adet ödeme oluştur
        for ($i = 0; $i < 10; $i++) {
            Payment::create([
                'user_id' => $users->random()->id, // Rastgele bir kullanıcı
                'invoice_id' => $invoices->random()->id, // Rastgele bir fatura
                'amount' => mt_rand(1000, 5000) / 100, // Rastgele bir tutar
                'payment_date' => Carbon::now()->subDays(rand(1, 30)), // Rastgele bir tarih
                'payment_method' => $paymentMethods[array_rand($paymentMethods)], // Rastgele ödeme yöntemi
                'transaction_id' => 'TXN-' . strtoupper(uniqid()), // Benzersiz işlem ID
            ]);
        }
    }
}
