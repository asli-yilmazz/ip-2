<?php

namespace Database\Seeders;

use App\Models\HostingPackage;
use App\Models\HostingPricing;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class HostingPricingsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $packages = HostingPackage::all();

        $pricingData = [
            ['billing_cycle' => 'monthly', 'price' => 9.99],
            ['billing_cycle' => 'annual', 'price' => 99.99],
        ];

        foreach ($packages as $package) {
            foreach ($pricingData as $data) {
                HostingPricing::create([
                    'package_id' => $package->id,
                    'billing_cycle' => $data['billing_cycle'],
                    'price' => $data['price'],
                ]);
            }
        }
    }

}
