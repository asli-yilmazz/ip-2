<?php

namespace Database\Seeders;

use App\Models\DomainExtension;
use App\Models\DomainPricing;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DomainPricingsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // DomainExtension modelini kullanarak, domain_extensions tablosundan bir uzantıyı seçiyoruz.
        $comExtension = DomainExtension::where('extension', '.com')->first();
        $netExtension = DomainExtension::where('extension', '.net')->first();
        $orgExtension = DomainExtension::where('extension', '.org')->first();
        $ioExtension = DomainExtension::where('extension', '.io')->first();
        $coExtension = DomainExtension::where('extension', '.co')->first();
        $techExtension = DomainExtension::where('extension', '.tech')->first();
        $bizExtension = DomainExtension::where('extension', '.biz')->first();
        $meExtension = DomainExtension::where('extension', '.me')->first();
        $aiExtension = DomainExtension::where('extension', '.ai')->first();
        $appExtension = DomainExtension::where('extension', '.app')->first();


        DomainPricing::create([
            'extension_id' => $comExtension->id,
            'created_price' => 12.99,
            'updated_price' => 10.99,
        ]);

        DomainPricing::create([
            'extension_id' => $netExtension->id,
            'created_price' => 10.99,
            'updated_price' => 8.99,
        ]);

        DomainPricing::create([
            'extension_id' => $orgExtension->id,
            'created_price' => 11.99,
            'updated_price' => 9.99,
        ]);

        DomainPricing::create([
            'extension_id' => $ioExtension->id,
            'created_price' => 29.99,
            'updated_price' => 27.99,
        ]);

        DomainPricing::create([
            'extension_id' => $coExtension->id,
            'created_price' => 23.99,
            'updated_price' => 20.99,
        ]);

        DomainPricing::create([
            'extension_id' => $techExtension->id,
            'created_price' => 19.99,
            'updated_price' => 17.99,
        ]);

        DomainPricing::create([
            'extension_id' => $bizExtension->id,
            'created_price' => 14.99,
            'updated_price' => 12.99,
        ]);

        DomainPricing::create([
            'extension_id' => $meExtension->id,
            'created_price' => 16.99,
            'updated_price' => 14.99,
        ]);

        DomainPricing::create([
            'extension_id' => $aiExtension->id,
            'created_price' => 59.99,
            'updated_price' => 49.99,
        ]);

        DomainPricing::create([
            'extension_id' => $appExtension->id,
            'created_price' => 29.99,
            'updated_price' => 25.99,
        ]);
    }
}
