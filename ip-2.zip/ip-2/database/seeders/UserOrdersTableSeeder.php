<?php

namespace Database\Seeders;

use App\Models\HostingOrder;
use App\Models\User;
use App\Models\UserOrder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserOrdersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $users = User::take(5)->get(); // İlk 5 kullanıcı
        $orders = HostingOrder::take(10)->get(); // İlk 10 hosting order

        foreach ($orders as $order) {
            UserOrder::create([
                'user_id' => $users->random()->id, // Rastgele bir kullanıcı ata
                'order_id' => $order->id, // Mevcut hosting order ID'sini ata
            ]);
        }
    }
}
