<?php

namespace Database\Seeders;

use App\Models\Domain;
use App\Models\HostingOrder;
use App\Models\HostingPackage;
use App\Models\HostingServer;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class HostingOrdersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::take(3)->get(); // İlk 3 kullanıcıyı al
        $packages = HostingPackage::take(3)->get(); // İlk 3 hosting paketi
        $domains = Domain::take(3)->get(); // İlk 3 domain
        $servers = HostingServer::take(3)->get(); // İlk 3 server

        $statuses = ['Active', 'Canceled', 'Expired'];

        for ($i = 0; $i < 10; $i++) {
            HostingOrder::create([
                'user_id' => $users[$i % $users->count()]->id,
                'package_id' => $packages[$i % $packages->count()]->id,
                'domain_id' => $domains[$i % $domains->count()]->id,
                'server_id' => $servers[$i % $servers->count()]->id,
                'order_date' => Carbon::now()->subDays(rand(1, 365)),
                'expiry_date' => Carbon::now()->addDays(rand(1, 365)),
                'status' => $statuses[array_rand($statuses)],
            ]);
        }
    }
}
