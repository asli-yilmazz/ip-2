<?php

namespace Database\Seeders;

use App\Models\Cart;
use App\Models\HostingPackage;
use Illuminate\Database\Seeder;

class CartsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $packages = HostingPackage::all();
        $userIds = [1, 2, 3]; // Örnek kullanıcı ID'leri

        foreach ($userIds as $userId) {
            foreach ($packages as $package) {
                // HostingPackage fiyatını price olarak atama
                Cart::create([
                    'user_id' => $userId,
                    'cartable_id' => $package->id,
                    'cartable_type' => get_class($package),
                    'quantity' => 2, // Örnek miktar
                    'price' => $package->price, // HostingPackage modelindeki price alanını kullan
                ]);
            }
        }
    }
}
