<?php

namespace Database\Seeders;

use App\Models\DomainExtension;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DomainExtensionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DomainExtension::create([
            'extension' => '.com',
            'annual_price' => 12.99,
            'monthly_price' => 1.99,
            'description' => 'A popular domain extension for websites.',
        ]);

        DomainExtension::create([
            'extension' => '.net',
            'annual_price' => 10.99,
            'monthly_price' => 1.50,
            'description' => 'A domain extension used for network-related websites.',
        ]);

        DomainExtension::create([
            'extension' => '.org',
            'annual_price' => 11.99,
            'monthly_price' => 1.70,
            'description' => 'A domain extension primarily used for non-profit organizations.',
        ]);

        DomainExtension::create([
            'extension' => '.io',
            'annual_price' => 29.99,
            'monthly_price' => 2.50,
            'description' => 'A domain extension popular with tech startups and developers.',
        ]);

        DomainExtension::create([
            'extension' => '.co',
            'annual_price' => 23.99,
            'monthly_price' => 2.00,
            'description' => 'A domain extension often used as an alternative to .com.',
        ]);

        DomainExtension::create([
            'extension' => '.tech',
            'annual_price' => 19.99,
            'monthly_price' => 1.80,
            'description' => 'A domain extension for technology-related businesses.',
        ]);

        DomainExtension::create([
            'extension' => '.biz',
            'annual_price' => 14.99,
            'monthly_price' => 1.30,
            'description' => 'A domain extension suitable for business websites.',
        ]);

        DomainExtension::create([
            'extension' => '.me',
            'annual_price' => 16.99,
            'monthly_price' => 1.40,
            'description' => 'A domain extension popular for personal websites or portfolios.',
        ]);

        DomainExtension::create([
            'extension' => '.ai',
            'annual_price' => 59.99,
            'monthly_price' => 5.00,
            'description' => 'A domain extension used by artificial intelligence and tech-related projects.',
        ]);

        DomainExtension::create([
            'extension' => '.app',
            'annual_price' => 29.99,
            'monthly_price' => 2.50,
            'description' => 'A domain extension primarily used for applications and software.',
        ]);
    }
}
