<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            UsersTableSeeder::class,
            PasswordResetTokensTableSeeder::class,
            SessionsTableSeeder::class,
            DomainExtensionsTableSeeder::class,
            DomainPricingsTableSeeder::class,
            DomainsTableSeeder::class,
            HostingServersTableSeeder::class,
            HostingPackagesTableSeeder::class,
            HostingPricingsTableSeeder::class,
            InvoicesTableSeeder::class,
            CartItemsTableSeeder::class,
            CartsTableSeeder::class,
            HostingOrdersTableSeeder::class,
            PaymentsTableSeeder::class,
            UserOrdersTableSeeder::class,
            UsersTableSeeder::class,
            TestimonialSeeder::class,
        ]);
    }
}
