<?php

namespace Database\Seeders;

use App\Models\Domain;
use App\Models\DomainExtension;
use App\Models\DomainPricing;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DomainsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user1 = User::where('email', 'john.doe@example.com')->first();
        $user2 = User::where('email', 'jane.smith@example.com')->first();
        $user3 = User::where('email', 'alice.johnson@example.com')->first();

        // DomainExtensions
        $comExtension = DomainExtension::where('extension', '.com')->first();
        $netExtension = DomainExtension::where('extension', '.net')->first();
        $orgExtension = DomainExtension::where('extension', '.org')->first();
        $ioExtension = DomainExtension::where('extension', '.io')->first();

        // DomainPricings
        $comPricing = DomainPricing::where('extension_id', $comExtension->id)->first();
        $netPricing = DomainPricing::where('extension_id', $netExtension->id)->first();
        $orgPricing = DomainPricing::where('extension_id', $orgExtension->id)->first();
        $ioPricing = DomainPricing::where('extension_id', $ioExtension->id)->first();

        // Domain ekleme (10 tane veri ekleniyor)
        Domain::create([
            'domain_name' => 'example1' . $comExtension->extension,
            'user_id' => $user1->id,
            'extension_id' => $comExtension->id,
            'pricing_id' => $comPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example2' . $netExtension->extension,
            'user_id' => $user2->id,
            'extension_id' => $netExtension->id,
            'pricing_id' => $netPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example3' . $orgExtension->extension,
            'user_id' => $user3->id,
            'extension_id' => $orgExtension->id,
            'pricing_id' => $orgPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example4' . $ioExtension->extension,
            'user_id' => $user1->id,
            'extension_id' => $ioExtension->id,
            'pricing_id' => $ioPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example5' . $comExtension->extension,
            'user_id' => $user2->id,
            'extension_id' => $comExtension->id,
            'pricing_id' => $comPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example6' . $netExtension->extension,
            'user_id' => $user3->id,
            'extension_id' => $netExtension->id,
            'pricing_id' => $netPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example7' . $orgExtension->extension,
            'user_id' => $user1->id,
            'extension_id' => $orgExtension->id,
            'pricing_id' => $orgPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example8' . $ioExtension->extension,
            'user_id' => $user2->id,
            'extension_id' => $ioExtension->id,
            'pricing_id' => $ioPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example9' . $comExtension->extension,
            'user_id' => $user3->id,
            'extension_id' => $comExtension->id,
            'pricing_id' => $comPricing->id,
        ]);

        Domain::create([
            'domain_name' => 'example10' . $netExtension->extension,
            'user_id' => $user1->id,
            'extension_id' => $netExtension->id,
            'pricing_id' => $netPricing->id,
        ]);
    }
}
