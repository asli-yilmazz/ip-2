<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;


class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'John',
            'lastname' => 'Doe',
            'email' => 'john.doe@example.com',
            'password' => bcrypt('password123'),
        ]);

        User::create([
            'name' => 'Jane',
            'lastname' => 'Smith',
            'email' => 'jane.smith@example.com',
            'password' => bcrypt('password456'),
        ]);

        User::create([
            'name' => 'Alice',
            'lastname' => 'Johnson',
            'email' => 'alice.johnson@example.com',
            'password' => bcrypt('password789'),
        ]);

        User::create([
            'name' => 'Bob',
            'lastname' => 'Brown',
            'email' => 'bob.brown@example.com',
            'password' => bcrypt('password101'),
        ]);
    }

}
