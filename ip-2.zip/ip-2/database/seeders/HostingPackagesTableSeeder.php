<?php

namespace Database\Seeders;

use App\Models\HostingPackage;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class HostingPackagesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $packages = [
            [
                'package_name' => 'Basic Package',
                'disk_space' => '10GB',
                'bandwidth' => '100GB',
                'email_accounts' => 10,
                'databases' => 5,
            ],
            [
                'package_name' => 'Standard Package',
                'disk_space' => '50GB',
                'bandwidth' => '500GB',
                'email_accounts' => 50,
                'databases' => 20,
            ],
            [
                'package_name' => 'Premium Package',
                'disk_space' => '100GB',
                'bandwidth' => '1TB',
                'email_accounts' => 100,
                'databases' => 50,
            ],
            [
                'package_name' => 'Pro Package',
                'disk_space' => '200GB',
                'bandwidth' => '2TB',
                'email_accounts' => 200,
                'databases' => 100,
            ],
            [
                'package_name' => 'Enterprise Package',
                'disk_space' => '500GB',
                'bandwidth' => 'Unlimited',
                'email_accounts' => 500,
                'databases' => 200,
            ],
            [
                'package_name' => 'Starter Package',
                'disk_space' => '5GB',
                'bandwidth' => '50GB',
                'email_accounts' => 5,
                'databases' => 2,
            ],
            [
                'package_name' => 'Developer Package',
                'disk_space' => '150GB',
                'bandwidth' => '1.5TB',
                'email_accounts' => 150,
                'databases' => 75,
            ],
            [
                'package_name' => 'Business Package',
                'disk_space' => '300GB',
                'bandwidth' => '3TB',
                'email_accounts' => 300,
                'databases' => 150,
            ],
            [
                'package_name' => 'Cloud Package',
                'disk_space' => '1TB',
                'bandwidth' => 'Unlimited',
                'email_accounts' => 1000,
                'databases' => 500,
            ],
            [
                'package_name' => 'Unlimited Package',
                'disk_space' => 'Unlimited',
                'bandwidth' => 'Unlimited',
                'email_accounts' => 5000,
                'databases' => 1000,
                'price' => 9.99,
            ],
        ];
        foreach ($packages as $package) {
            HostingPackage::create($package);
        }
    }
}
