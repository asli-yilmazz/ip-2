<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TestimonialSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('testimonials')->insert([
            ['customer_name' => 'Ahmet Yılmaz', 'comment' => 'Mükemmel hizmet!'],
            ['customer_name' => 'Meryem Aydın', 'comment' => 'Hızlı ve güvenilir!'],
            ['customer_name' => 'Okan Yıldız', 'comment' => 'Destek ekibi çok ilgili.'],
        ]);
    }
}
