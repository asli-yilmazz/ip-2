<?php

namespace Database\Seeders;

use App\Models\HostingServer;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class HostingServersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        HostingServer::create([
            'server_name' => 'Server 1',
            'ip_address' => '192.168.1.1',
            'location' => 'New York',
            'max_storage' => '1000GB',
            'available_storage' => '800GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 2',
            'ip_address' => '192.168.1.2',
            'location' => 'Los Angeles',
            'max_storage' => '1500GB',
            'available_storage' => '1200GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 3',
            'ip_address' => '192.168.1.3',
            'location' => 'San Francisco',
            'max_storage' => '2000GB',
            'available_storage' => '1500GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 4',
            'ip_address' => '192.168.1.4',
            'location' => 'Chicago',
            'max_storage' => '500GB',
            'available_storage' => '300GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 5',
            'ip_address' => '192.168.1.5',
            'location' => 'Dallas',
            'max_storage' => '750GB',
            'available_storage' => '600GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 6',
            'ip_address' => '192.168.1.6',
            'location' => 'Miami',
            'max_storage' => '1200GB',
            'available_storage' => '1000GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 7',
            'ip_address' => '192.168.1.7',
            'location' => 'Austin',
            'max_storage' => '250GB',
            'available_storage' => '200GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 8',
            'ip_address' => '192.168.1.8',
            'location' => 'Seattle',
            'max_storage' => '3000GB',
            'available_storage' => '2500GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 9',
            'ip_address' => '192.168.1.9',
            'location' => 'San Diego',
            'max_storage' => '200GB',
            'available_storage' => '150GB',
        ]);

        HostingServer::create([
            'server_name' => 'Server 10',
            'ip_address' => '192.168.1.10',
            'location' => 'Atlanta',
            'max_storage' => '1500GB',
            'available_storage' => '1300GB',
        ]);
    }
}
