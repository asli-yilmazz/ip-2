<?php

namespace Database\Seeders;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Domain;
use App\Models\HostingPackage;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CartItemsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $carts = Cart::take(5)->get(); // İlk 5 sepet
        $hostingPackages = HostingPackage::take(5)->get(); // İlk 5 hosting paketi
        $domains = Domain::take(5)->get(); // İlk 5 domain

        // HostingPackage ürünlerini ekle
        foreach ($carts as $cart) {
            foreach ($hostingPackages as $package) {
                CartItem::create([
                    'cart_id' => $cart->id, // Sepet ID
                    'product_id' => $package->id, // Hosting Package ID
                    'product_type' => HostingPackage::class, // Polymorphic type
                    'quantity' => rand(1, 3), // 1 ile 3 arasında rastgele miktar
                    'price' => rand(50, 100), // Rastgele fiyat
                ]);
            }
        }

        // Domain ürünlerini ekle
        foreach ($carts as $cart) {
            foreach ($domains as $domain) {
                CartItem::create([
                    'cart_id' => $cart->id, // Sepet ID
                    'product_id' => $domain->id, // Domain ID
                    'product_type' => Domain::class, // Polymorphic type
                    'quantity' => 1, // Domain için miktar genelde 1 olur
                    'price' => rand(10, 50), // Rastgele fiyat
                ]);
            }
        }
    }
}
