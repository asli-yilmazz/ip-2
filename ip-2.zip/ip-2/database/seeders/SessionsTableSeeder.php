<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SessionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('sessions')->insert([
            'id' => 'session_id_1',
            'user_id' => 1,  // Kullanıcı id'si
            'ip_address' => '192.168.1.1',
            'user_agent' => 'Mozilla/5.0',
            'payload' => 'payload_data_1',
            'last_activity' => time(),
        ]);

        DB::table('sessions')->insert([
            'id' => 'session_id_2',
            'user_id' => 2,
            'ip_address' => '192.168.1.2',
            'user_agent' => 'Mozilla/5.0',
            'payload' => 'payload_data_2',
            'last_activity' => time(),
        ]);
    }
}
