<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id(); // Otomatik artan id
            $table->unsignedBigInteger('user_id'); // Kullanıcı kimliği
            $table->unsignedBigInteger('invoice_id'); // İlgili fatura
            $table->decimal('amount', 10, 2); // Ödeme tutarı
            $table->timestamp('payment_date'); // Ödeme tarihi
            $table->enum('payment_method', ['credit_card', 'paypal', 'bank_transfer', 'cash']); // Ödeme yöntemi
            $table->string('transaction_id')->nullable(); // Ödeme işlem kimliği (isteğe bağlı)
            $table->timestamps(); // created_at ve updated_at

            // Foreign key ilişkileri
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('invoice_id')->references('id')->on('invoices')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
