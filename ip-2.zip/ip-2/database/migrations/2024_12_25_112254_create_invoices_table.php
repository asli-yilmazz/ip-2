<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id(); // Otomatik artan id
            $table->unsignedBigInteger('user_id'); // Kullanıcı kimliği
            $table->string('invoice_number'); // Fatura numarası
            $table->decimal('total_amount', 10, 2); // Toplam fatura tutarı
            $table->enum('status', ['paid', 'unpaid', 'cancelled']); // Fatura durumu
            $table->timestamps(); // created_at ve updated_at

            // Foreign key ilişkisi
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('invoices');
    }
};
