@extends('layouts.app')

@section('title', 'Hosting Siparişi')

@section('content')
    <div class="container">
        <h1>Hosting Siparişi</h1>
        <p>Seçtiğiniz Paket: <strong>{{ $package->name }}</strong></p>
        <p>Aylık Fiyat: <strong>{{ number_format($package->price, 2) }} TL</strong></p>

        <form action="{{ route('hosting.processOrder') }}" method="POST">
            @csrf
            <input type="hidden" name="package_id" value="{{ $package->id }}">
            <button type="submit" class="btn-primary">Siparişi Tamamla</button>
        </form>
    </div>
@endsection
