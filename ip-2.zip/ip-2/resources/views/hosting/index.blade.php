@extends('layouts.app')

@section('title', 'Hosting Paketleri')

@section('content')
    <div class="container">
        <h1>Hosting Paketleri</h1>
        <div class="row">
            @foreach ($hostingPackages as $package)
                <div class="col-md-4">
                    <h3>{{ $package->name }}</h3>
                    <p>{{ $package->description }}</p>
                    <p>Fiyat: {{ $package->price }} TL</p>

                    <!-- Sipariş Formu -->
                    <form action="{{ route('hosting.processOrder') }}" method="POST">
                        @csrf
                        <input type="hidden" name="package_id" value="{{ $package->id }}">
                        <button type="submit" class="btn btn-primary">Siparişi Tamamla</button>
                    </form>
                </div>
            @endforeach
        </div>
    </div>
@endsection
