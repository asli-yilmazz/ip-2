@extends('layouts.app')

@section('title', 'Alan Adı Siparişi')

@section('content')
    <div class="container">
        <h1>Alan Adı Siparişi</h1>
        <p><strong>Alan Adı:</strong> {{ $domainService->name }}</p>
        <p><strong>Açıklama:</strong> {{ $domainService->description }}</p>
        <p><strong>Fiyat:</strong> {{ number_format($domainService->price, 2) }} TL</p>

        <form action="{{ route('domain.order.submit', $domainService->id) }}" method="POST">
            @csrf
            <button type="submit" class="btn btn-primary">Siparişi Tamamla</button>
        </form>
    </div>
@endsection
