@extends('layouts.app')

@section('title', 'Ana Sayfa')

@section('content')
    <!-- Navbar -->
    <header class="navbar">
        <div class="container">
            <div class="navbar-left">
                <a href="{{ route('home') }}" class="navbar-logo">Web Hosting</a>
            </div>
            <div class="navbar-right">
                <a href="{{ route('signup') }}" class="btn-primary">Kayıt Ol</a>
                <a href="{{ route('login') }}" class="btn-secondary">Giriş Yap</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Web Hosting ve Alan Adı Yönetimi</h1>
            <p>Web siteniz için en güvenilir hosting ve alan adı hizmetleri.</p>
            <a href="{{ route('services') }}" class="btn-primary">Hizmetleri Keşfet</a>
        </div>
    </section>


    <section class="domain-extensions">
        <div class="container">
            <h2>Alan Adı Uzantıları</h2>
            <div class="extension-list">
                @foreach ($domainExtensions as $extension)
                    <div class="extension-item">
                        <h3>{{ $extension->name }}</h3>
                        <p>Yıllık Fiyat: {{ number_format($domainPricings->where('domain_extension_id', $extension->id)->first()->price ?? 0, 2) }} TL</p>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- Hosting Packages Section -->
    <section class="hosting-packages">
        <div class="container">
            <h2>Hosting Paketleri</h2>
            <div class="package-list">
                @foreach ($hostingPackages as $package)
                    <div class="package-item">
                        <h3>{{ $package->name }}</h3>
                        <p>{{ $package->description }}</p>
                        <p>Fiyat: {{ $package->price ? number_format($package->price, 2) : 'Fiyat Bilgisi Yok' }} TL/ay</p>
                        <a href="{{ route('hosting.order', $package->id) }}" class="btn-secondary">Satın Al</a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials">
        <div class="container">
            <h2>Müşteri Yorumları</h2>
            <div class="testimonial-list">
                @foreach ($testimonials as $testimonial)
                    <div class="testimonial-item">
                        <blockquote>
                            <p>{{ $testimonial->comment }}</p>
                            <footer>- {{ $testimonial->customer_name }}</footer>
                        </blockquote>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- Call to Action Section -->
    <section class="cta">
        <div class="container">
            <h2>Web Sitenizi Hemen Kurun!</h2>
            <p>Hosting ve alan adı paketlerimizi keşfedin ve dakikalar içinde yayınlanmaya başlayın.</p>
            <a href="{{ route('signup') }}" class="btn-primary">Hemen Başla</a>
        </div>
    </section>
@endsection
