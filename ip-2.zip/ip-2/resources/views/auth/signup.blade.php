@extends('layouts.app')

@section('title', 'Kayıt Ol')

@section('content')
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

    <div class="container">
        <h1>Kayıt Ol</h1>
        <form action="{{ route('signup') }}" method="POST">
            @csrf
            <div>
                <label for="name">İsim:</label>
                <input type="text" name="name" id="name" required>
            </div>
            <div>
                <label for="lastname">Soyisim:</label>
                <input type="text" name="lastname" id="lastname" required>
            </div>
            <div>
                <label for="email">E-posta:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div>
                <label for="password">Şifre:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <div>
                <label for="password_confirmation">Şifre (Tekrar):</label>
                <input type="password" name="password_confirmation" id="password_confirmation" required>
            </div>
            <button type="submit">Kayıt Ol</button>
        </form>
    </div>
    <style>
        /* Genel Stil */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            max-width: 500px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        label {
            font-size: 16px;
            color: #333;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
            outline: none;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #4CAF50;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Hata mesajları */
        .error {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }

    </style>
@endsection
